
Install vcredist.exe first.  (It installs quickly, and without feedback to the user.)

